package com.sgnt.integration;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

import io.restassured.*;

/**
 * TODO: Document me!
 *
 * @author Peter java.net.UnknownHostException: netaccess-test.transunion.com
 *
 */
public class Testing {
    /**
     * @param args
     */
    final static String[] certs = { "COOPER15_SHA2.p12" };
    private static final String trustStorePath = System.getProperty("java.io.tmpdir") + File.separator
            + "test.keystore";
  
    
       

    public static void main(String[] args) throws Exception {
        
//       InputStream certIs=new FileInputStream("Cooper15_sha2.jks");
//        KeyStore ks=KeyStore.getInstance("PKCS12");
//      //  ks.load(certIs.getInputStream(),"password".toCharArray());
//        Certificate cert=ks.getCertificate("alias");
//        
            
            
           // keystore.store(new FileOutputStream(trustStorePath), password);
            System.setProperty("javax.net.ssl.trustStore", trustStorePath);
            System.setProperty("javax.net.ssl.trustStorePassword", "TuC00p25");
            System.setProperty("javax.net.ssl.trustStoreType", "PKCS12");

            HttpURLConnection con = null;
            URLConnection urlc = null;
            String json;
            String request = null;
            String tmp;
            String data;
            String address = "https://netaccess-test.transunion.com";

//            String clientPassword = "TuC00p25";
//            String clientCertificatePath = "C:/Users/Peter/Desktop/bday/COOPER15_SHA2.p12";
//            String trustStorePath = "C:/Program Files/Java/jre-1.8/lib/security/cacerts";
//            String trustStorePassword = "changeit"; // default trust store
//                                                    // password

            String response = null;
            PrintStream ps = null;
            BufferedReader br = null;
            String line;

            String t24data = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n<xmlrequest xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope\" xmlns=\"http://www.netaccess.transunion.com/namespace\">\r\n    <systemId>COOPER15</systemId>\r\n    <systemPassword>TuC00p25</systemPassword>\r\n    <productrequest>\r\n        <creditBureau xmlns=\"http://www.transunion.com/namespace\">\r\n            <document>request</document>\r\n            <version>2.0</version>\r\n            <transactionControl>\r\n                <userRefNumber>XYZ_123_APPLICATION_328</userRefNumber>\r\n                <subscriber>\r\n                    <industryCode>Q</industryCode>\r\n                    <memberCode>4883343</memberCode>\r\n                    <inquirySubscriberPrefixCode>0622</inquirySubscriberPrefixCode>\r\n                    <password>PSWD</password>\r\n                </subscriber>\r\n                <options>\r\n                    <processingEnvironment>production</processingEnvironment>\r\n                    <country>us</country>\r\n                    <language>en</language>\r\n                    <contractualRelationship>individual</contractualRelationship>\r\n                    <pointOfSaleIndicator>none</pointOfSaleIndicator>\r\n                </options>\r\n            </transactionControl>\r\n            <product>\r\n                <code>07350</code>\r\n                <subject>\r\n                    <number>1</number>\r\n                    <subjectRecord>\r\n                        <indicative>\r\n                            <name>\r\n                                <person>\r\n                                    <alsoReportedAs>false</alsoReportedAs>\r\n                                    <first>ALANA</first>\r\n                                    <middle />\r\n                                    <last>FILE</last>\r\n                                    <generationalSuffix />\r\n                                </person>\r\n                            </name>\r\n                            <address>\r\n                                <status>current</status>\r\n                                <street>\r\n                                    <unparsed>5TH ST</unparsed>\r\n                                </street>\r\n                                <location>\r\n                                    <city>FANTASY ISLAND</city>\r\n                                    <state>IL</state>\r\n                                    <zipCode>60750</zipCode>\r\n                                </location>\r\n                            </address>\r\n                            <socialSecurity>\r\n                                <number>892462577</number>\r\n                            </socialSecurity>\r\n                            <dateOfBirth>1910-01-01</dateOfBirth>\r\n                            <phone>\r\n                                <number>\r\n                                    <type>standard</type>\r\n                                    <areaCode>123</areaCode>\r\n                                    <exchange>456</exchange>\r\n                                    <suffix>7890</suffix>\r\n                                </number>\r\n                            </phone>\r\n                        </indicative>\r\n                    </subjectRecord>\r\n                </subject>\r\n            </product>\r\n        </creditBureau>\r\n    </productrequest>\r\n</xmlrequest>";

            try {
                String fulladdress = address + t24data;
                URL url = null;
                url = new URL(fulladdress);
                boolean justOpenConnect = false;
                if (urlc == null) {
                    con = (HttpsURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    justOpenConnect = true;
                }

                if (justOpenConnect) {
                    String encoding = null;
                    con.setRequestProperty("Content-Type", "text/xml");
                    con.setDoInput(true);
                    con.setUseCaches(false);
                    con.setDoOutput(true);
                    con.setAllowUserInteraction(false);
                    con.connect();
                }

                ps = new PrintStream(con.getOutputStream());
                ps.print(request);
                ps.close();
                br = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                if (br == null) {

                    line = null;
                } else {
                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                        sb.append("\n");
                    }

                    br.close();
                    response = sb.toString();
                    System.out.println(response);
                }

            } catch (Exception var20) {

                System.out.println(var20);
                System.out.println(response);
            } finally {
                if (ps != null) {
                    ps = null;
                }

                if (br != null) {
                    br = null;
                }

                if (urlc != null) {
                    urlc = null;
                }

            }

        }

    }
