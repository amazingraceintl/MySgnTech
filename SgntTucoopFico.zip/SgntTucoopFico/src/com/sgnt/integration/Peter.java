package com.sgnt.integration;

import java.io.IOException;
import java.io.InputStream;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
/**
 * TODO: Document me!
 *
 * @author Peter 401 error response
 *
 */
public class Peter {
    private URLConnection urlc = null;
    private HttpURLConnection con = null;
    public static String json;
    private static String request;
    public static String tmp;
    public String data;
    public static String address = "https://netaccess-test.transunion.com";

    
    /**
     * @param args
     * @throws IOException 
     */
    public static void main(String[] args) throws Exception, MalformedURLException, IOException {
        // TODO Auto-generated method stub
       
    
         request = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n<xmlrequest xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope\" xmlns=\"http://www.netaccess.transunion.com/namespace\">\r\n    <systemId>COOPER15</systemId>\r\n    <systemPassword>TuC00p25</systemPassword>\r\n    <productrequest>\r\n        <creditBureau xmlns=\"http://www.transunion.com/namespace\">\r\n            <document>request</document>\r\n            <version>2.0</version>\r\n            <transactionControl>\r\n                <userRefNumber>XYZ_123_APPLICATION_328</userRefNumber>\r\n                <subscriber>\r\n                    <industryCode>Q</industryCode>\r\n                    <memberCode>4883343</memberCode>\r\n                    <inquirySubscriberPrefixCode>0622</inquirySubscriberPrefixCode>\r\n                    <password>J2SP</password>\r\n                </subscriber>\r\n                <options>\r\n                    <processingEnvironment>standardTest</processingEnvironment>\r\n                    <country>us</country>\r\n                    <language>en</language>\r\n                    <contractualRelationship>individual</contractualRelationship>\r\n                    <pointOfSaleIndicator>none</pointOfSaleIndicator>\r\n                </options>\r\n            </transactionControl>\r\n            <product>\r\n                <code>07350</code>\r\n                <subject>\r\n                    <number>1</number>\r\n                    <subjectRecord>\r\n                        <indicative>\r\n                            <name>\r\n                                <person>\r\n                                    <alsoReportedAs>false</alsoReportedAs>\r\n                                    <first>ALANA</first>\r\n                                    <middle />\r\n                                    <last>FILE</last>\r\n                                    <generationalSuffix />\r\n                                </person>\r\n                            </name>\r\n                            <address>\r\n                                <status>current</status>\r\n                                <street>\r\n                                    <unparsed>5TH ST</unparsed>\r\n                                </street>\r\n                                <location>\r\n                                    <city>FANTASY ISLAND</city>\r\n                                    <state>IL</state>\r\n                                    <zipCode>60750</zipCode>\r\n                                </location>\r\n                            </address>\r\n                            <socialSecurity>\r\n                                <number>892462577</number>\r\n                            </socialSecurity>\r\n                            <dateOfBirth>1910-01-01</dateOfBirth>\r\n                            <phone>\r\n                                <number>\r\n                                    <type>standard</type>\r\n                                    <areaCode>123</areaCode>\r\n                                    <exchange>456</exchange>\r\n                                    <suffix>7890</suffix>\r\n                                </number>\r\n                            </phone>\r\n                        </indicative>\r\n                    </subjectRecord>\r\n                </subject>\r\n            </product>\r\n        </creditBureau>\r\n    </productrequest>\r\n</xmlrequest>";
        System.out.println("generating json...");
        
        URL url = new URL("https://netaccess-test.transunion.com");
        URLConnection connection = url.openConnection();
        HttpURLConnection httpConn = (HttpURLConnection) connection;
        String SOAPAction = "";
        
        ByteArrayInputStream bin = new ByteArrayInputStream(request.getBytes());
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        copy(bin, bout);
        byte[] b = bout.toByteArray();

        System.out.println(b.toString().getBytes().toString());
        // Set the appropriate HTTP parameters.
        httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
        httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
       // httpConn.setRequestProperty("SOAPAction", SOAPAction);
        httpConn.setRequestMethod("POST");
        httpConn.setDoOutput(true);
        httpConn.setDoInput(true);
        // Everything's set up; send the XML that was read in to b.
        OutputStream out = httpConn.getOutputStream();
        out.write(b);
        out.close();
        // Read the response and write it to standard out.
        
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
        BufferedReader in = new BufferedReader(isr);
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
        System.out.println("what is here..."+inputLine);

        }
        in.close();
        
    }
    public static void copy(InputStream in, OutputStream out) throws IOException {
        synchronized (in) {
        synchronized (out) {
        byte[] buffer = new byte[256];
        while (true) {
        int bytesRead = in.read(buffer);
        if (bytesRead == -1) {
        break;
        }}}}}
}
