package com.sgnt.integration;

/**
 * TODO: Document me!
 *
 * @author Peter
 *
 */
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;

import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
public class NewTest {

    
    /**
     * @param args
     */
        public static void main(String[] args) throws ClientProtocolException, IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, UnrecoverableKeyException, NoSuchProviderException {
            System.setProperty("javax.net.ssl.trustStore","tucoop.keystore");
            System.setProperty("javax.net.ssl.trustStorePassword","TuC00p25");
            
            KeyStore clientStore = KeyStore.getInstance("PKCS12");
            clientStore.load(new FileInputStream(new File("C:/Users/Peter/Music/COOPER15_SHA2.p12")), "TuC00p25".toCharArray());
            
            
           
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(clientStore, "TuC00p25".toCharArray());
            KeyManager[] kms = kmf.getKeyManagers();
            
            
            // Assuming that you imported the CA Cert "Subject: CN=MBIIS CA, OU=MBIIS, O=DAIMLER, C=DE"
            // to your cacerts Store.
            KeyStore trustStore = KeyStore.getInstance("JKS");
            trustStore.load(new FileInputStream("C:/Users/Peter/Music/COOPER15_SHA2.p12"), "TuC00p25".toCharArray());
            
           TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(trustStore);
            TrustManager[] tms = tmf.getTrustManagers();
            
            
            

            final SSLContext sslContext = SSLContext.getInstance("TLS");
           sslContext.init(kms,tms,new SecureRandom());
            SSLContext.setDefault(sslContext);

            HostnameVerifier hostnameVerifier = NoopHostnameVerifier.INSTANCE;   
            System.setProperty("https.proxyHost", "IP_OF_PROXY_HOST_GOES_HERE");
            System.setProperty("https.proxyPort", "PORT_NUMBER_GOES_HERE");
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);
            
            //disableCertificateValidation();

            String t24data = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n<xmlrequest xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope\" xmlns=\"http://www.netaccess.transunion.com/namespace\">\r\n    <systemId>COOPER15</systemId>\r\n    <systemPassword>TuC00p25</systemPassword>\r\n    <productrequest>\r\n        <creditBureau xmlns=\"http://www.transunion.com/namespace\">\r\n            <document>request</document>\r\n            <version>2.0</version>\r\n            <transactionControl>\r\n                <userRefNumber>XYZ_123_APPLICATION_328</userRefNumber>\r\n                <subscriber>\r\n                    <industryCode>Q</industryCode>\r\n                    <memberCode>4883343</memberCode>\r\n                    <inquirySubscriberPrefixCode>0622</inquirySubscriberPrefixCode>\r\n                    <password>PSWD</password>\r\n                </subscriber>\r\n                <options>\r\n                    <processingEnvironment>production</processingEnvironment>\r\n                    <country>us</country>\r\n                    <language>en</language>\r\n                    <contractualRelationship>individual</contractualRelationship>\r\n                    <pointOfSaleIndicator>none</pointOfSaleIndicator>\r\n                </options>\r\n            </transactionControl>\r\n            <product>\r\n                <code>07350</code>\r\n                <subject>\r\n                    <number>1</number>\r\n                    <subjectRecord>\r\n                        <indicative>\r\n                            <name>\r\n                                <person>\r\n                                    <alsoReportedAs>false</alsoReportedAs>\r\n                                    <first>ALANA</first>\r\n                                    <middle />\r\n                                    <last>FILE</last>\r\n                                    <generationalSuffix />\r\n                                </person>\r\n                            </name>\r\n                            <address>\r\n                                <status>current</status>\r\n                                <street>\r\n                                    <unparsed>5TH ST</unparsed>\r\n                                </street>\r\n                                <location>\r\n                                    <city>FANTASY ISLAND</city>\r\n                                    <state>IL</state>\r\n                                    <zipCode>60750</zipCode>\r\n                                </location>\r\n                            </address>\r\n                            <socialSecurity>\r\n                                <number>892462577</number>\r\n                            </socialSecurity>\r\n                            <dateOfBirth>1910-01-01</dateOfBirth>\r\n                            <phone>\r\n                                <number>\r\n                                    <type>standard</type>\r\n                                    <areaCode>123</areaCode>\r\n                                    <exchange>456</exchange>\r\n                                    <suffix>7890</suffix>\r\n                                </number>\r\n                            </phone>\r\n                        </indicative>\r\n                    </subjectRecord>\r\n                </subject>\r\n            </product>\r\n        </creditBureau>\r\n    </productrequest>\r\n</xmlrequest>";

            URL url = new URL("https://netaccess-test.transunion.com");
            
            URLConnection connection = url.openConnection();
            HttpURLConnection httpConn = (HttpURLConnection) connection;
            String SOAPAction = "";
        
            ByteArrayInputStream bin = new ByteArrayInputStream(t24data.getBytes());
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            copy(bin, bout);
            byte[] b = bout.toByteArray();

            System.out.println(b.toString().toString());
            // Set the appropriate HTTP parameters.
            httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
            httpConn.setRequestProperty("Content-Type", "text/xml");
           // httpConn.setRequestProperty("SOAPAction", SOAPAction);
            httpConn.setRequestMethod("POST");
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            // Everything's set up; send the XML that was read in to b.
            OutputStream out = httpConn.getOutputStream();
            out.write(b);
            out.close();
            // Read the response and write it to standard out.
            
            InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
            BufferedReader in = new BufferedReader(isr);
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
            System.out.println(inputLine);

            }
            in.close();
               
        }
        
        public static void copy(InputStream in, OutputStream out) throws IOException {
            synchronized (in) {
            synchronized (out) {
            byte[] buffer = new byte[256];
            while (true) {
            int bytesRead = in.read(buffer);
            if (bytesRead == -1) {
            break;
            }

            out.write(buffer, 0, bytesRead);

            }}}}
        
        public static void disableCertificateValidation() {
            // Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }//from   www  . j a  va2 s .  c om

                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            } };

            // Ignore differences between given hostname and certificate hostname
            HostnameVerifier hv = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            

            // Install the all-trusting trust manager
            try {
                SSLContext sc = SSLContext.getInstance("TLS");
                sc.init(null, trustAllCerts, new SecureRandom());
                HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
                HttpsURLConnection.setDefaultHostnameVerifier(hv);
            } catch (Exception e) {
                //Ignore
            }
        }
}

